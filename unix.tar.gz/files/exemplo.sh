echo "O conteúdo da sua variável de ambiente \$PATH é: $PATH"
